# Installation

Install the fonts normally.
